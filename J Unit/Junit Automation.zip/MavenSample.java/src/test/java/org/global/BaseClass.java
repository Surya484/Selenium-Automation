package org.global;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	public static WebDriver driver;

	public void getDriver() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

	}

	public void getDriverEdge() {
		WebDriverManager.edgedriver().setup();
		driver = new EdgeDriver();

	}

	public void getUrl(String url) {
		driver.get(url);
	}

	public void winMax() {
		driver.manage().window().maximize();

	}

	public void textSend(WebElement element, String keysToSend) {
		element.sendKeys(keysToSend);

	}

	public void textSendByJS(WebElement element, String keysToSend) {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('value','" + keysToSend + "')", element);

	}

	public void screenCapture(String name) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		File target = new File("C:\\Users\\Admin\\Pictures\\TakesScreenShot\\" + name + ".jpeg");
		FileUtils.copyFile(source, target);

	}

	public void selectByValue(WebElement element, String value) {

		Select s = new Select(element);
		s.selectByValue(value);

	}
	
	public void selectByVisibleText(WebElement element, String value) {

		Select s = new Select(element);
		s.selectByVisibleText(value);

	}
	
	public void login() {
		WebElement login = driver.findElement(By.id("login"));
		login.click();
	}
	
	public void submit() {
		WebElement submit = driver.findElement(By.id("Submit"));
		submit.click();
	}
	
	public void radioClick() {
		WebElement radioClick = driver.findElement(By.id("radiobutton_0"));
		radioClick.click();

	}
	
	public void continueButton() {
		WebElement continueButton = driver.findElement(By.id("continue"));
		continueButton.click();

	}


	public String readExcel(int rownum, int cellnum) throws IOException {
		// To Locate File
		File file = new File("C:\\Users\\Admin\\Documents\\Excel\\Excel1.xlsx");

		// To get File as a INput Data
		FileInputStream stream = new FileInputStream(file);

		// To Define Workbook // XSSF / HSSF
		Workbook book = new XSSFWorkbook(stream);

		// To get sheet from book
		Sheet sheet = book.getSheet("Sheet3");

		// To get Row from Sheet
		Row row = sheet.getRow(rownum);

		// To get Cell from Row
		Cell cell = row.getCell(cellnum);

		// To get Cell Type of Cell
		CellType cellType = cell.getCellType();
 
		 String value = null ;
		 
		switch (cellType) {
		case STRING:
			 value = cell.getStringCellValue();
			break;

		case NUMERIC:
			if (DateUtil.isCellDateFormatted(cell)) {

				Date dateCellValue = cell.getDateCellValue();
				SimpleDateFormat simple = new SimpleDateFormat("dd/MM/yyyy");
				 value = simple.format(dateCellValue);
			} else {

				double numericCellValue = cell.getNumericCellValue();
				BigDecimal valueOf = BigDecimal.valueOf(numericCellValue);
				 value = valueOf.toString();
			}
			break;

		default:
			break;
		}
		return value;

	}

}