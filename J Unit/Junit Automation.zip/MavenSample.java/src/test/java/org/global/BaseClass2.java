package org.global;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass2 {
	public static WebDriver driver;
	
	public void getDriver() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

	}
	
	public void getUrl(String url) {
		driver.get(url);

	}
	
	public void winMax() {
		driver.manage().window().maximize();

	}
	
	public void textSend(WebElement element, String keysToSend) {
		element.sendKeys(keysToSend);

	}
	
	public void login() {
		WebElement login = driver.findElement(By.id("login-button"));
		login.click();
	}
	
	public void addToCart6() {
		List<WebElement> addToCart = driver.findElements(By.xpath("//button[text()='Add to cart']"));
		for(int i=0; i<addToCart.size(); i++) {
			addToCart.get(i).click();
		}

	}
	
	public void remove2() {
		List<WebElement> remove = driver.findElements(By.xpath("//button[text()='Remove']"));
		for(int i=0; i<2; i++) {
			remove.get(i).click();
		}

	}
	
	public void cart() {
		WebElement cart = driver.findElement(By.xpath("//a[@class='shopping_cart_link']"));
		cart.click();

	}
	
	public void checkOut() {
		WebElement checkOut = driver.findElement(By.id("checkout"));
		checkOut.click();

	}
	
	public void clickContinue() {
		WebElement clickContinue = driver.findElement(By.id("continue"));
		clickContinue.click();

	}
	
	public void finish() {
		WebElement finish = driver.findElement(By.id("finish"));
		finish.click();

	}
	
	public void home() {
		WebElement home = driver.findElement(By.id("react-burger-menu-btn"));
		home.click();

	}
	
	public void logOut() {
		WebElement logOut = driver.findElement(By.id("logout_sidebar_link"));
		logOut.click();

	}

}
