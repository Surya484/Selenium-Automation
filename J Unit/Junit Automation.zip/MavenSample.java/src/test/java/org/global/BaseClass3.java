package org.global;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass3 {
public static WebDriver driver;
	
	public void getDriver() {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
        options.setBinary("C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe");
		driver = new ChromeDriver(options);

	}
	
	public void getDriver2() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
	}
	
	public void getUrl(String url) {
		driver.get(url);

	}
	
	public void winMax() {
		driver.manage().window().maximize();

}
	
	public void textSend(WebElement element, String keysToSend) {
		element.sendKeys(keysToSend);

	}

	public void textSendByJS(WebElement element, String keysToSend) {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('value','" + keysToSend + "')", element);

	}

	public void screenCapture(String name) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		File target = new File("C:\\Users\\Admin\\Pictures\\TakesScreenShot\\" + name + ".jpeg");
		FileUtils.copyFile(source, target);

	}

	public void selectByValue(WebElement element, String value) {

		Select s = new Select(element);
		s.selectByValue(value);

	}
	
	public void selectByVisibleText(WebElement element, String value) {

		Select s = new Select(element);
		s.selectByVisibleText(value);

	}
	
	public  void signUp() {
		WebElement signUp = driver.findElement(By.xpath("//a[text()=' Signup / Login']"));
		signUp.click();
	}
	
	
	public void clickSignUp() {
		WebElement clickSignUp = driver.findElement(By.xpath("//button[text()='Signup']"));
		clickSignUp.click();
	}
	
	public void title() {
		WebElement title = driver.findElement(By.xpath("//input[@id='id_gender1']"));
		title.click();
	}
}