package org.pageclass;

import org.global.BaseClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageClass extends BaseClass{
	public PageClass() {
		
		PageFactory.initElements(driver, this);
		
	}
		
		@FindBy(how=How.XPATH,using="//input[@id='username']")
		private WebElement userName;

		public WebElement getUserName() {
			return userName;
		}
		
		
		@FindBy(how=How.XPATH,using="//input[@id='password']")
		private WebElement password;
		
		public WebElement getPassword() {
			return password;
		}
		
		
		@FindBy(how=How.XPATH,using="//select[@id='location']")
		private WebElement location;
		
		public WebElement getLocation() {
			return location;
		}
		
		
		@FindBy(how=How.XPATH,using="//select[@id='hotels']")
		private WebElement hotel;
		
		public WebElement getHotel() {
			return hotel;
		}
		
		
		@FindBy(how=How.XPATH,using="//select[@id='room_type']")
		private WebElement roomType;
		
		public WebElement getRoomType() {
			return roomType;
		}
		
		
		@FindBy(how=How.XPATH,using="//select[@id='room_nos']")
		private WebElement noOfRooms;
		
		public WebElement getNoOfRooms() {
			return noOfRooms;
		}
		
		
		@FindBy(how=How.XPATH,using="//input[@id='datepick_in']")
		private WebElement checkIn;
		
		public WebElement getCheckIn() {
			return checkIn;
		}
		
		
		@FindBy(how=How.XPATH,using="//input[@id='datepick_out']")
		private WebElement checkOut;
		
		public WebElement getCheckOut() {
			return checkOut;
		}
		
		
		@FindBy(how=How.XPATH,using="//select[@id='adult_room']")
		private WebElement adultsPerRoom;
		
		public WebElement getAdultsPerRoom() {
			return adultsPerRoom;
		}
		
		
		@FindBy(how=How.XPATH,using="//select[@id='child_room']")
		private WebElement childrenPerRoom;
		
		public WebElement getChildrenPerRoom() {
			return childrenPerRoom;
		}


}
