package org.pageclass;

import org.global.BaseClass2;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageClass2 extends BaseClass2{
	public PageClass2() {
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(id="user-name")
	private WebElement userName;
	
	public WebElement getUserName() {
		return userName;
	}
	
	@FindBy(id="password")
	private WebElement password;
	
	public WebElement getPassword() {
		return password;
	}
	
	@FindBy(id="first-name")
	private WebElement firstName;
	
	public WebElement getFirstName() {
		return firstName;
	}
	
	@FindBy(id="last-name")
	private WebElement lastName;
	
	public WebElement getLastName() {
		return lastName;
	}
	
	@FindBy(id="postal-code")
	private WebElement postalCode;
	
	public WebElement getPostalCode() {
		return postalCode;
	}
	
}