package org.pageclass;

import org.global.BaseClass3;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageClass3 extends BaseClass3 {
	
	public PageClass3() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH,using="//input[@name='name']")
	private WebElement name;
	
	public WebElement getName() {
		return name;
	}
	
	@FindBy(how=How.XPATH,using="//input[@data-qa='signup-email']")
	private WebElement email;
	
	public WebElement getEmail() {
		return email;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='name']")
	private WebElement name2;
	
	public WebElement getName2() {
		return name2;
	}
	
	@FindBy(how=How.XPATH,using="//a[text()=' Signup / Login']")
	private WebElement click;
	
	public WebElement getClick() {
		return click;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='password']")
	private WebElement password;
	
	public WebElement getPassword() {
		return password;
	}
	
	@FindBy(how=How.XPATH,using="//select[@id='days']")
	private WebElement day;
	
	public WebElement getDay() {
		return day;
	}
	
	@FindBy(how=How.XPATH,using="//select[@id='months']")
	private WebElement month;
	
	public WebElement getMonth() {
		return month;
	}
	
	@FindBy(how=How.XPATH,using="//select[@id='years']")
	private WebElement year;
	
	public WebElement getYear() {
		return year;
	}
	
	@FindBy(how=How.XPATH,using="//label[@for='newsletter']")
	public WebElement signUpReason;
	
	public WebElement getSignUpReason() {
		return signUpReason;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='first_name']")
	private WebElement firstName;
	
	public WebElement getFirstName() {
		return firstName;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='last_name']")
	private WebElement lastName;
	
	public WebElement getLastName() {
		return lastName;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='company']")
	private WebElement companyName;
	
	public WebElement getCompanyName() {
		return companyName;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='address1']")
	private WebElement address1;
	
	public WebElement getAddress1() {
		return address1;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='address2']")
	private WebElement address2;
	
	public WebElement getAddress2() {
		return address2;
	}
	
	@FindBy(how=How.XPATH,using="//select[@id='country']")
	private WebElement country;
	
	public WebElement getCountry() {
		return country;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='state']")
	private WebElement state;
	
	public WebElement getState() {
		return state;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='city']")
	private WebElement city;
	
	public WebElement getCity() {
		return city;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='zipcode']")
	private WebElement zipcode;
	
	public WebElement getZipcode() {
		return zipcode;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='mobile_number']")
	private WebElement mobileNo;
	
	public WebElement getMobileNo() {
		return mobileNo;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='Create Account']")
	private WebElement createAccount;
	
	public WebElement getCreateAccount() {
		return createAccount;
	}
	
	@FindBy(how=How.XPATH,using="//a[text()='Continue']")
	public WebElement clickContinue;
	
	public WebElement getClickContinue() {
		return clickContinue;
	}
	
	@FindBy(how=How.XPATH,using="//a[text()=' Delete Account']")
	public WebElement clickDeleteAccount;
	
	public WebElement getClickDeleteAccount() {
		return clickDeleteAccount;
	}

}
