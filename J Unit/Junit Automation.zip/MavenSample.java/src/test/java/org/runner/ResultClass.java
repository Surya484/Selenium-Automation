package org.runner;

import java.util.List;

import org.junit.runner.Description;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class ResultClass {
	
	public static void main(String[] args) {
		
		Result runClasses = JUnitCore.runClasses(TestRunnerClass.class);
		boolean wasSuccessful = runClasses.wasSuccessful();
		
		if(wasSuccessful) {
			System.out.println("The TestRunnerClass is executed Successfully");
		}
		
		int failureCount = runClasses.getFailureCount();
		System.out.println("The Failure Count is "+failureCount);
		
		int ignoreCount = runClasses.getIgnoreCount();
		System.out.println("Ignore Count is "+ignoreCount);
		
		int runCount = runClasses.getRunCount();
		System.out.println("Run Count is "+runCount);
		
		long runTime = runClasses.getRunTime();
		System.out.println("Run Time is "+runTime);
		
		List<Failure> failures = runClasses.getFailures();
		
		int size = failures.size();
		System.out.println(size);
		
		for (Failure failure : failures) {
			
			Description description = failure.getDescription();
			String string = description.toString();
			System.out.println("Description "+string);
			
			Throwable exception = failure.getException();
			String string2 = exception.toString();
			System.out.println("Exception "+string2);
			
			String message = failure.getMessage();
			System.out.println("Error Message "+message);
			
			String trace = failure.getTrace();
			System.out.println("Trace "+trace);
			
			
		}
		
		
		
		
	}

}
