package org.runner;

import org.sample.Junit;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import org.sample.Junit2;

@RunWith(Suite.class)
@SuiteClasses({Junit.class, Junit2.class})
public class TestRunnerClass {

}
