package org.sample;
import org.global.BaseClass3;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.pageclass.PageClass3;

public class Junit extends BaseClass3{
	
	public static BaseClass3 b;
	public static PageClass3 p;
	
	@BeforeClass
	public static void launchUrl() {
		try {
			
			b = new BaseClass3();
			
			b.getDriver();
			b.getUrl("https://automationexercise.com/");
			b.winMax();
			
			WebElement validateHomePage = driver.findElement(By.tagName("h1"));
			if(validateHomePage.isDisplayed()) {
				System.out.println("Home page is visible");
			}
		} catch (Exception e) {
			
		}
			
	}
	
	
	@Before
	public void signUpPage() {
		try {
			
			b = new BaseClass3();
			
			b.signUp();
			
			WebElement ValidateSignUpPage = driver.findElement(By.xpath("//h2[text()='New User Signup!']"));
			if(ValidateSignUpPage.isDisplayed()) {
				System.out.println("New User Sign Up is visible");
			}
			
			p = new PageClass3();
			
			WebElement name = p.getName();
			b.textSendByJS(name, "Greens");
			
			WebElement email = p.getEmail();
			b.textSendByJS(email, "grens2024@gmail.com");
			
			b.clickSignUp();
		} catch (Exception e) {
			
		}
		
	}
	
	
	@Test
	public void signUpDetails() {
		try {
			
			b = new BaseClass3();
			
			WebElement validateNewUserSignUp = driver.findElement(By.xpath("//b[text()='Enter Account Information']"));
			if(validateNewUserSignUp.isDisplayed()) {
				System.out.println("Enter Account Information Page is Visible");
			}
			
			b.title();
			
			p = new PageClass3();
			
			WebElement name2 = p.getName2();
			b.textSendByJS(name2, "abc");
			
			WebElement password = p.getPassword();
			b.textSendByJS(password, "rytyf");
			
			WebElement day = p.getDay();
			b.selectByVisibleText(day, "17");
			
			WebElement month = p.getMonth();
			b.selectByValue(month, "4");
			
			WebElement year = p.getYear();
			b.selectByVisibleText(year, "2009");
			
			WebElement signUpReason = p.getSignUpReason();
			signUpReason.click();
			
			WebElement firstName = p.getFirstName();
			b.textSendByJS(firstName, "Surya");
			
			WebElement lastName = p.getLastName();
			b.textSendByJS(lastName, "R");
			
			WebElement companyName = p.getCompanyName();
			b.textSendByJS(companyName, "Greens");
			
			WebElement address1 = p.getAddress1();
			b.textSendByJS(address1, "velachery");
			
			WebElement address2 = p.getAddress2();
			b.textSendByJS(address2, "Chennai");
			
			WebElement country = p.getCountry();
			b.selectByValue(country, "India");
			
			WebElement state = p.getState();
			b.textSendByJS(state, "Tamil Nadu");
			
			WebElement city = p.getCity();
			b.textSendByJS(city, "Chennai");
			
			WebElement zipcode = p.getZipcode();
			b.textSendByJS(zipcode, "646473");
			
			WebElement mobileNo = p.getMobileNo();
			b.textSendByJS(mobileNo, "9634327364");
			
			WebElement createAccount = p.getCreateAccount();
			createAccount.click();
			
		} catch (Exception e) {
			
		}

	}
	
	
	@After
	public void validateAccountCreation() {
		try {
			
			p = new PageClass3();
			
			WebElement validateCreatedAccount = driver.findElement(By.xpath("//b[text()='Account Created!']"));
			if(validateCreatedAccount.getText().equals("")) {
				System.out.println("The Account is Successfully created");
			}
			
			WebElement clickContinue = p.getClickContinue();
			clickContinue.click();
			
			WebElement validateLoginUsername = driver.findElement(By.xpath("//a[text()=' Logged in as ']"));
			if(validateLoginUsername.isDisplayed()) {
				System.out.println("The Webpage logged in by username is visible");
			}
			
		} catch (Exception e) {
			
		}

	}
	
	
	@AfterClass
	public static void deleteAccount() {
		try {
			
			p = new PageClass3();
			
			WebElement clickDeleteAccount = p.getClickDeleteAccount();
			clickDeleteAccount.click();
			
			WebElement validateDeletedAccount = driver.findElement(By.xpath("//b[text()='Account Deleted!']"));
			if(validateDeletedAccount.isDisplayed()) {
				System.out.println("The Account is Deleted");
			}
			
			WebElement clickContinue2 = p.getClickContinue();
			clickContinue2.click();
			
		} catch (Exception e) {
			
		}

	}
		

}
